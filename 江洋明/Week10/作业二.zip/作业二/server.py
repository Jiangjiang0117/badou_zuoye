import random
from datetime import datetime
from fastmcp import FastMCP
from typing import Union
import zoneinfo

# ============================================================
# 1. 初始化 FastMCP 服务端实例
#    name: MCP server 的名字，会在 client 端 / Agent 里暴露出来
# ============================================================
mcp = FastMCP(name="Demo MCP Server")

# ------------------------------------------------------------
# 原工具 1：摇骰子（保留）
#   工具名：roll_dice
#   入参：n_dice (int)  -> 摇几次
#   返回：list[int]     -> 每次的结果
# ------------------------------------------------------------
@mcp.tool
def roll_dice(n_dice: int) -> list[int]:
    """Roll `n_dice` 6-sided dice and return the results."""
    return [random.randint(10, 60) for _ in range(n_dice)]


# ------------------------------------------------------------
# 原工具 2：取最新新闻（保留）
# ------------------------------------------------------------
@mcp.tool
def get_news() -> Union[int, str]:
    """Get latest news."""
    return "最新消息 Qwen4 is coming!"


# ============================================================
# 2. 新增工具 1：查询某城市的天气（模拟）
#   工具名：get_weather
#   入参：city (str) -> 城市名
#   返回：str        -> 天气描述
# ------------------------------------------------------------
@mcp.tool
def get_weather(city: str) -> str:
    """
    查询指定城市的天气（这里是模拟数据，方便演示 MCP tool 调用）。
    Args:
        city: 城市名称，例如 "北京"、"上海"、"Shenzhen"
    Returns:
        一个简单的天气描述字符串。
    """
    # 模拟几个常见城市的天气，其它城市随机返回
    fixed = {
        "北京":   "晴，25°C，微风",
        "上海":   "多云，28°C，东南风",
        "深圳":   "雷阵雨，31°C，湿度大",
        "广州":   "阴，30°C",
    }
    if city in fixed:
        return f"{city}：{fixed[city]}"
    # 用 hash 让结果稳定一些，方便调试
    temp = 15 + (hash(city) % 20)
    cond = random.choice(["晴", "多云", "小雨", "阴"])
    return f"{city}：{cond}，约 {temp}°C"


# ============================================================
# 3. 新增工具 2：数学表达式求值（安全版本）
#   工具名：calculate
#   入参：expression (str) -> 形如 "12 + 3 * 5" 的数学表达式
#   返回：float            -> 计算结果
#   备注：用 ast 解析，避免直接 eval() 带来的安全风险
# ------------------------------------------------------------
import ast
import operator as op

# 支持的二元运算符白名单
_BIN_OPS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.FloorDiv: op.floordiv,
    ast.Mod: op.mod,
    ast.Pow: op.pow,
}
_UNARY_OPS = {ast.UAdd: op.pos, ast.USub: op.neg}


def _safe_eval(node):
    """递归求值 AST 节点，仅允许数字和上面的运算符"""
    if isinstance(node, ast.Num):                     # Python 3.7 兼容写法
        return node.n
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
        return _BIN_OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
        return _UNARY_OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError(f"不支持的表达式节点: {ast.dump(node)}")


@mcp.tool
def calculate(expression: str) -> float:
    """
    安全地计算一个数学表达式并返回数值结果。
    Args:
        expression: 仅包含数字和 + - * / // % ** 括号的算式，例如 "(2+3)*4"
    Returns:
        计算结果（float）
    """
    tree = ast.parse(expression, mode="eval")
    return float(_safe_eval(tree.body))


# ============================================================
# 4. 新增工具 3：获取当前时间（支持时区）
#   工具名：get_current_time
#   入参：tz (str) -> 时区名，默认 "Asia/Shanghai"
#   返回：str      -> 格式化后的时间字符串
# ------------------------------------------------------------
@mcp.tool
def get_current_time(tz: str = "Asia/Shanghai") -> str:
    """
    获取指定时区的当前时间。
    Args:
        tz: IANA 时区名，例如 "Asia/Shanghai"、"UTC"、"America/New_York"。
           默认 "Asia/Shanghai"。
    Returns:
        形如 "2026-10-15 14:30:25 CST" 的字符串。
    """
    try:
        zone = zoneinfo.ZoneInfo(tz)
    except Exception as e:
        return f"未知时区: {tz} ({e})"
    now = datetime.now(zone)
    return now.strftime("%Y-%m-%d %H:%M:%S %Z")


# ============================================================
# 5. 启动 MCP server
#    transport="sse" 表示走 Server-Sent Events
#    客户端通过 http://localhost:8000/sse 连接
# ============================================================
if __name__ == "__main__":
    mcp.run(transport="sse", port=8000)