import os

# ============================================================
# 1. 配置 OpenAI 兼容接口（沿用作业一的 SiliconFlow 配置）
# ============================================================
os.environ["OPENAI_API_KEY"] = "sk-khlzqgggbrjyvllonlaqwmdsmpmswdhbxlddbfvehormwgdn"
os.environ["OPENAI_BASE_URL"] = "https://api.siliconflow.cn/v1"

import asyncio
from agents import Agent, Runner, AsyncOpenAI, OpenAIChatCompletionsModel
from agents.mcp import MCPServer
from agents.mcp.server import MCPServerSse
from agents import set_default_openai_api, set_tracing_disabled

# ============================================================
# 2. 配置 SDK 全局行为
#    - chat_completions: 用 Chat Completions 协议（非 Responses）
#    - tracing disabled: 关闭链路追踪，避免上报
# ============================================================
set_default_openai_api("chat_completions")
set_tracing_disabled(True)


async def run(mcp_server: MCPServer):
    """
    跑一个接入了 MCP 工具的 Agent。
    内部流程（SDK 自动完成）：
        step1: 通过 MCP client list tools -> 拿到 mcp server 暴露的工具清单
        step2: 把工具清单转成 function calling 格式 -> 让大模型选一个工具 + 填参
        step3: MCP client 调 mcp server execute tool -> 拿到执行结果
        step4: 把工具结果塞回提示词 -> 让大模型生成最终回答
    """

    # 3. 构造 OpenAI 兼容客户端（指向上面配置的 SiliconFlow）
    external_client = AsyncOpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url=os.environ["OPENAI_BASE_URL"],
        timeout=120.0,          # 开源模型高峰期慢，拉长超时
        max_retries=2,
    )

    # 4. 构造 Agent，mcp_servers 列表告诉它有哪些 MCP 工具可用
    agent = Agent(
        name="Assistant",
        instructions=(
            "你是一个助手，可以使用下列 MCP 工具来回答用户问题：\n"
            "- roll_dice: 摇 N 个 6 面骰子\n"
            "- get_news: 获取最新新闻\n"
            "- get_weather: 查询指定城市的天气\n"
            "- calculate: 计算数学表达式\n"
            "- get_current_time: 获取指定时区的当前时间\n"
            "请优先调用合适的工具，再给出最终中文回答。"
        ),
        mcp_servers=[mcp_server],   # 关键：把 MCP server 挂到 Agent 上
        model=OpenAIChatCompletionsModel(
            model="Qwen/Qwen3-32B",    # SiliconFlow 上真实存在的开源模型
            openai_client=external_client,
        ),
    )

    # ========================================================
    # 5. 用 Agent 跑 5 个测试用例（覆盖 5 个工具）
    #    每次 Runner.run 都会自动经历 list tool -> 选 -> 调 -> 总结
    # ========================================================
    test_cases = [
        ("最近有什么新闻？",                              "原工具 get_news"),
        ("摇3次骰子得到结果。",                          "原工具 roll_dice"),
        ("深圳今天天气怎么样？",                          "新工具 get_weather"),
        ("帮我算一下 (12 + 8) * 3 - 5 / 2 等于多少。",  "新工具 calculate"),
        ("现在北京时间几点？再告诉我纽约现在是几点。",   "新工具 get_current_time（两次）"),
    ]

    for i, (message, hint) in enumerate(test_cases, start=1):
        print("\n" + "=" * 60)
        print(f"Case {i} ({hint})")
        print(f"Running: {message}")
        result = await Runner.run(starting_agent=agent, input=message)
        print(">> 最终输出:", result.final_output)


async def main():
    """
    通过 SSE 连接 mcp server（默认 http://localhost:8000/sse）
    注意：使用前必须先启动 server.py：
        python server.py
    """
    async with MCPServerSse(
        name="SSE Python Server",
        params={
            "url": "http://localhost:8000/sse",   # 与 server.py 端口保持一致
        },
    ) as server:
        await run(server)


if __name__ == "__main__":
    asyncio.run(main())