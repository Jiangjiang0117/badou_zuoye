"""SQL Agent 命令行入口。

用法：
    python run_agent.py "每个国家消费总额最高的 3 位客户是谁？"
    python run_agent.py "各流派歌曲数量 Top10" "再看看它们的平均时长"   # 多轮追问
    python run_agent.py --self-check                                    # 不需要 API Key 的自检
    python run_agent.py -v "问题"                                       # 打印每一步轨迹
"""

import argparse
import io
import sys

# Windows 终端中文编码（见 CLAUDE.md）
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

from sql_agent import config
from sql_agent.agent import SQLAgent, StepTrace, WorkflowError
from sql_agent.db_parser import DBParser
from sql_agent.sql_validator import validate_sql

DEMO_QUESTIONS = [
    "每个国家消费总额最高的 3 位客户是谁？",
    "统计各音乐流派的歌曲数量和平均时长，按歌曲数量降序取前 10",
    "2012 年销售金额最高的 5 张专辑",
    "哪些员工负责的客户数量最多？",
]


def print_step(step: StepTrace) -> None:
    """打印单个步骤的轨迹。"""
    mark = "OK " if step.ok else "ERR"
    print(f"  [{mark}] {step.name}  ({step.elapsed_ms:.0f}ms)")
    if step.detail:
        for line in step.detail.splitlines():
            print(f"        {line}")
    if step.error:
        print(f"        ! {step.error}")


def run_question(questions: list[str], verbose: bool) -> int:
    agent = SQLAgent()
    try:
        for i, question in enumerate(questions, 1):
            if len(questions) > 1:
                print(f"\n{'=' * 70}\n第 {i} 轮提问：{question}\n{'=' * 70}")
            elif verbose:
                print(f"{'=' * 70}\n{question}\n{'=' * 70}")

            try:
                answer = agent.run(question, on_step=print_step if verbose else None)
            except WorkflowError as e:
                print(f"\nWorkflow 失败：{e}")
                return 1

            if not verbose:
                print(f"\n问题  : {question}")
                print(f"选表  : {answer.tables}")
                print(f"SQL   : {answer.sql}")
                print(f"改写  : {answer.rewrites} 轮")
                print(f"耗时  : {answer.elapsed_ms:.0f}ms，返回 {answer.row_count} 行")

            print(f"\n数据（{answer.row_count} 行）：")
            print(answer.df.to_string(index=False, max_rows=20))
            print(f"\n回答：{answer.summary}")
    finally:
        agent.close()
    return 0


def self_check() -> int:
    """不依赖大模型的自检：解析 -> 校验规则 -> 执行。

    没有 API Key 也能跑，用来验证除选表/生成/改写/汇总以外的所有环节。
    """
    print("=" * 70)
    print("SQL Agent 自检（不需要 API Key）")
    print("=" * 70)

    # ---- ① 数据库解析 ----
    import time

    t0 = time.time()
    parser = DBParser()
    print(f"\n[① 数据库解析] 耗时 {time.time() - t0:.1f}s")
    print(f"  表 {len(parser.table_names)} 张: {', '.join(parser.table_names)}")
    print(f"  外键 {len(parser.foreign_keys)} 条")
    print(f"  各表行数: "
          + ", ".join(f"{t}={parser.get_row_count(t)}" for t in parser.table_names))

    print("\n  表结构摘要示例（invoices）：")
    summary = parser.schema_summary(["invoices", "customers"])
    print("\n".join("    " + ln for ln in summary.splitlines()[:14]))

    # ---- ④ SQL 校验：规则用例 ----
    print(f"\n[④ SQL 校验] 规则用例")
    cases = [
        ("合法查询", "SELECT Country, COUNT(*) FROM customers GROUP BY Country", True),
        ("不存在的表", "SELECT * FROM orders", False),
        ("不存在的列", "SELECT NoSuchColumn FROM customers", False),
        ("DELETE 写操作", "DELETE FROM invoices", False),
        ("DROP 写操作", "DROP TABLE customers", False),
        ("PRAGMA", "PRAGMA table_info(customers)", False),
        ("多语句拼接", "SELECT 1 FROM customers; DROP TABLE customers", False),
        ("字符串里含 delete 不误伤",
         "SELECT * FROM customers WHERE LastName = 'delete'", True),
        ("字符串里含 update 不误伤",
         "SELECT * FROM tracks WHERE Name LIKE '%update%'", True),
        ("CTE 不被误判成不存在的表",
         "WITH c AS (SELECT Country FROM customers) SELECT * FROM c", True),
        ("REPLACE 函数不算写操作",
         "SELECT REPLACE(Name, 'a', 'b') FROM artists", True),
        ("无 LIMIT 自动补齐",
         "SELECT * FROM customers", True),
    ]
    passed = failed = 0
    for name, sql, should_pass in cases:
        result = validate_sql(sql, parser)
        got_limit = "LIMIT" in result.sql.upper() and "LIMIT" not in sql.upper()
        actual = result.ok
        status = "PASS" if actual == should_pass else "FAIL"
        if status == "PASS":
            passed += 1
        else:
            failed += 1
        note = " [已自动补 LIMIT]" if got_limit and should_pass else ""
        detail = result.errors[0][:60] if result.errors else ""
        print(f"  {status}  {name}{note}" + (f"  -> {detail}" if detail else ""))

    print(f"\n  校验用例: {passed} 通过, {failed} 失败")

    # ---- ⑥ SQL 执行 ----
    print(f"\n[⑥ SQL 执行]")
    executor_ok = validate_sql(
        "SELECT c.Country, SUM(i.Total) AS 总额 FROM customers c "
        "JOIN invoices i ON c.CustomerId = i.CustomerId "
        "GROUP BY c.Country ORDER BY 总额 DESC LIMIT 5",
        parser,
    )
    if executor_ok.ok:
        from sql_agent.sql_executor import SQLExecutor

        ex = SQLExecutor()
        try:
            result = ex.execute(executor_ok.sql)
            print(result.df.to_string(index=False))
            print(f"  {result.row_count} 行，{result.elapsed_ms:.1f}ms")
        finally:
            ex.close()

    parser.close()

    print(f"\n{'=' * 70}")
    print(f"自检结果: {'全部通过' if failed == 0 else str(failed) + ' 项失败'}")
    print("注意：选表/生成/改写/汇总这四步依赖大模型，需要配置 DASHSCOPE_API_KEY 才能验证。")
    print("=" * 70)
    return 0 if failed == 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="基于 chinook.db 的 SQL Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("questions", nargs="*", help="自然语言问题，可传多个做多轮追问")
    parser.add_argument("-v", "--verbose", action="store_true", help="打印每一步的执行轨迹")
    parser.add_argument("--self-check", action="store_true", help="不需要 API Key 的自检")
    parser.add_argument("--demo", action="store_true", help="依次跑内置的 4 个示例问题")
    args = parser.parse_args()

    if args.self_check:
        return self_check()

    if not config.DASHSCOPE_API_KEY:
        print("错误：未配置 DASHSCOPE_API_KEY。\n"
              "请复制 .env.example 为 .env 并填入你的 DashScope API Key。\n"
              "（想先看看流程可以跑：python run_agent.py --self-check）",
              file=sys.stderr)
        return 1

    questions = DEMO_QUESTIONS if args.demo else args.questions
    if not questions:
        parser.print_help()
        return 1

    return run_question(questions, args.verbose)


if __name__ == "__main__":
    raise SystemExit(main())