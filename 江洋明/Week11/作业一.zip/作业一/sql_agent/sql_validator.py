"""④ SQL 校验。

纯静态规则，不调用大模型，因此又快又便宜，是流程里最可靠的一道闸门。
大模型生成的 SQL 必须先过这里才允许执行。

R1 单语句      必须以 SELECT/WITH 开头，且不能是多语句拼接
R2 危险关键字  拒绝一切 DML/DDL/PRAGMA 等写操作
R3 表存在性    FROM/JOIN 里的表必须真实存在
R4 LIMIT 兜底  没有 LIMIT 就自动补上，防止全表扫描拖垮数据库
R5 预演校验    在只读连接上跑 EXPLAIN QUERY PLAN，提前暴露语法/列名/函数错误
"""

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from . import config

if TYPE_CHECKING:  # 避免循环导入
    from .db_parser import DBParser

# 注释和字符串字面量要先剥掉再扫关键字，
# 否则 SELECT 'delete me' 这种正常查询会被误判成写操作
_COMMENT_RE = re.compile(r"--[^\n]*|/\*.*?\*/", re.DOTALL)
_STRING_RE = re.compile(r"'(?:[^']|'')*'")
_DQUOTED_RE = re.compile(r'"[^"]*"')

# 写操作 / 危险操作一律拒绝。
# 注意不含 REPLACE：它是合法的 SQL 函数 REPLACE(x,y,z)，
# 而 INSERT OR REPLACE 已经被 INSERT 规则拦下了。
FORBIDDEN_KEYWORDS = (
    "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", "TRUNCATE",
    "ATTACH", "DETACH", "PRAGMA", "VACUUM", "REINDEX", "GRANT", "REVOKE",
)

_TABLE_RE = re.compile(r"\b(?:FROM|JOIN)\s+([`\"\[]?)([A-Za-z_]\w*)\1", re.IGNORECASE)
_CTE_RE = re.compile(r"(?:\bWITH\b|,)\s*(?:RECURSIVE\s+)?([A-Za-z_]\w*)\s+AS\s*\(", re.IGNORECASE)


@dataclass
class ValidationResult:
    """校验结果。ok=True 时 sql 是规范化后的 SQL（可能已被补上 LIMIT）。"""

    ok: bool = False
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    sql: str = ""


def _strip_noise(sql: str) -> str:
    """去掉注释和字符串字面量，只留结构，用于关键字和表名扫描。"""
    sql = _COMMENT_RE.sub(" ", sql)
    sql = _STRING_RE.sub("''", sql)
    return _DQUOTED_RE.sub('""', sql)


def _referenced_tables(sql: str) -> set[str]:
    """提取 FROM/JOIN 引用的表名，并排除 WITH 子句自己定义的 CTE 名。"""
    cte_names = {m.group(1).lower() for m in _CTE_RE.finditer(_strip_noise(sql))}
    return {
        m.group(2).lower()
        for m in _TABLE_RE.finditer(_strip_noise(sql))
        if m.group(2).lower() not in cte_names
    }


def validate_sql(sql: str, parser: "DBParser | None" = None) -> ValidationResult:
    """校验 SQL 是否安全且可执行。

    parser 为 None 时跳过 R5（预演校验），其余规则照常执行。
    """
    result = ValidationResult(sql=sql)
    cleaned = _strip_noise(sql or "").strip()

    if not cleaned:
        result.errors.append("SQL 为空")
        return result

    # ---- R1 只允许单条查询语句 ----
    statements = [s for s in _strip_noise(sql).split(";") if s.strip()]
    if len(statements) > 1:
        result.errors.append(f"检测到 {len(statements)} 条语句，只允许执行单条 SELECT 查询")
    if not re.match(r"^\s*(SELECT|WITH)\b", cleaned, re.IGNORECASE):
        head = cleaned.split()[0] if cleaned.split() else cleaned[:20]
        result.errors.append(f"只允许 SELECT 或 WITH 开头的查询，实际以 '{head}' 开头")

    # ---- R2 危险关键字 ----
    found = [
        kw for kw in FORBIDDEN_KEYWORDS
        if re.search(rf"\b{kw}\b", cleaned, re.IGNORECASE)
    ]
    if found:
        result.errors.append(f"SQL 含有被禁止的写操作关键字：{', '.join(found)}")

    # ---- R3 表存在性 ----
    if parser is not None:
        unknown = _referenced_tables(sql) - {t.lower() for t in parser.table_names}
        if unknown:
            result.errors.append(
                f"SQL 引用了不存在的表：{', '.join(sorted(unknown))}；"
                f"数据库中只有 {', '.join(parser.table_names)}"
            )

    # ---- R4 LIMIT 兜底 ----
    normalized = sql.strip().rstrip(";").strip()
    if not re.search(r"\bLIMIT\b", cleaned, re.IGNORECASE):
        normalized = f"{normalized} LIMIT {config.DEFAULT_LIMIT}"
        result.warnings.append(f"SQL 没有 LIMIT，已自动补上 LIMIT {config.DEFAULT_LIMIT} 防止全表扫描")
    result.sql = normalized

    if result.errors:
        return result

    # ---- R5 预演校验：EXPLAIN 让 SQLite 真正解析并规划查询 ----
    # 这是最可靠的列名/语法检查，比正则准得多：未知列会直接抛 "no such column: X"。
    if parser is not None:
        try:
            df = parser.execute_sql("EXPLAIN QUERY PLAN " + normalized)
            plan = " | ".join(str(v) for v in df.iloc[:, -1].tolist())
            result.warnings.append(f"执行计划：{plan[:200]}")
        except Exception as e:
            result.errors.append(f"SQL 预演失败：{type(e).__name__}: {e}")
            return result

    result.ok = True
    return result