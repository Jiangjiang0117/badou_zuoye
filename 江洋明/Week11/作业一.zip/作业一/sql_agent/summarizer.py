"""⑦ 结果汇总。

把最终 SQL 和查询结果交给大模型，生成一句面向业务的中文回答。
只展示结果的前若干行给模型看，避免 token 爆炸，同时在提示里说明总行数，
防止模型误以为"只查出了这几行"。
"""

from .llm import LLMClient
from .sql_executor import ExecResult

SUMMARIZE_SYSTEM = """你是一个数据分析助手，要根据 SQL 查询结果，用中文回答用户的问题。

【回答要求】
1. 直接给出结论，3-5 句话，自然语言表达，不要罗列 SQL 或表格。
2. 必须引用结果里的具体数字（金额、个数、名称），不要编造没查到的数据。
3. 结果行数较多时，做概括性总结（例如"巴西消费最高，前三名分别……"），
   而不是逐行复述。
4. 如果结果为空，直接说明没有符合条件的数据。
5. 只输出回答正文，不要写"根据查询结果"之类的开场白。"""

SUMMARIZE_USER = """【用户问题】
{question}

【执行的 SQL】
```sql
{sql}
```

【查询结果】共 {row_count} 行，最多展示前 {shown} 行：
{table}

请回答用户的问题。"""


class Summarizer:
    """基于大模型的结果汇总。"""

    def __init__(self, llm: LLMClient) -> None:
        self.llm = llm

    def summarize(
        self, question: str, sql: str, result: ExecResult, max_rows: int = 20
    ) -> str:
        table = result.to_text(max_rows=max_rows)
        user = SUMMARIZE_USER.format(
            question=question,
            sql=sql,
            row_count=result.row_count,
            shown=min(result.row_count, max_rows),
            table=table,
        )
        return self.llm.chat(SUMMARIZE_SYSTEM, user).strip()