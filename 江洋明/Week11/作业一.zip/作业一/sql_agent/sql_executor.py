"""⑥ SQL 执行。

用独立的只读 sqlite3 连接执行查询（不复用 DBParser 的 SQLAlchemy 连接），
这样可以用 set_progress_handler 实现真正的执行超时——
SQLAlchemy 的 Connection 没有暴露这个能力。

只读做双重保险：URI 的 mode=ro 已经在数据库层挡住了写入，这里再加 PRAGMA query_only。
"""

import sqlite3
import time
from dataclasses import dataclass, field

import pandas as pd

from . import config


@dataclass
class ExecResult:
    """执行结果。"""

    df: pd.DataFrame
    row_count: int
    elapsed_ms: float
    truncated: bool = False
    warnings: list[str] = field(default_factory=list)

    def to_text(self, max_rows: int = 20) -> str:
        """转成可读文本，喂给大模型做结果汇总。"""
        if self.df.empty:
            return "（查询结果为空）"
        shown = self.df.head(max_rows)
        header = " | ".join(str(c) for c in shown.columns)
        rows = [
            " | ".join("NULL" if v is None else str(v) for v in row)
            for row in shown.itertuples(index=False)
        ]
        text = "\n".join([header] + rows)
        if len(self.df) > max_rows:
            text += f"\n...（共 {len(self.df)} 行，此处只显示前 {max_rows} 行）"
        return text


class SQLExecutor:
    """只读 SQL 执行器，带超时和行数截断。"""

    def __init__(self, db_file: str | None = None, timeout: int | None = None) -> None:
        self.db_file = db_file or str(config.DB_FILE)
        self.timeout = timeout if timeout is not None else config.SQL_TIMEOUT
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(
                f"file:{self.db_file}?mode=ro", uri=True, check_same_thread=False
            )
            self._conn.execute("PRAGMA query_only = 1")  # 第二层只读保险
        return self._conn

    def _install_timeout(self, deadline: float) -> None:
        """用 progress handler 实现超时。

        handler 每执行若干条 SQLite 虚机指令就被调用一次，
        超过 deadline 就返回非零中断整个查询。
        """
        import time as _time

        def handler() -> int:
            return 1 if _time.time() > deadline else 0

        self.conn.set_progress_handler(handler, 10_000)

    def execute(self, sql: str, max_rows: int | None = None) -> ExecResult:
        """执行 SQL。超时会抛 sqlite3.OperationalError('interrupted')。"""
        max_rows = max_rows if max_rows is not None else config.MAX_ROWS
        warnings: list[str] = []

        self._install_timeout(time.time() + self.timeout)
        start = time.time()
        try:
            cursor = self.conn.execute(sql)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description] if cursor.description else []
        finally:
            self.conn.set_progress_handler(None, 0)
        elapsed_ms = (time.time() - start) * 1000

        truncated = len(rows) > max_rows
        if truncated:
            warnings.append(f"结果有 {len(rows)} 行，超过上限，已截断为前 {max_rows} 行")
            rows = rows[:max_rows]

        return ExecResult(
            df=pd.DataFrame(rows, columns=columns),
            row_count=len(rows),
            elapsed_ms=elapsed_ms,
            truncated=truncated,
            warnings=warnings,
        )

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None