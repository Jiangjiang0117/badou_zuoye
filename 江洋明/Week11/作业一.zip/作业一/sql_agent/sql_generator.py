"""③ SQL 生成。

输入选中的表的详细结构（字段统计 + 样例行 + 可用 JOIN 条件），
让大模型产出 SQLite 查询。字段统计里的「取值范围」「众数」「样例值」是关键——
没有它们模型会写出 WHERE Country = 'China' 这种库里根本不存在的值。
"""

import re

from .db_parser import DBParser
from .llm import LLMClient

GENERATE_SYSTEM = """你是一个 SQL 专家，负责把中文取数需求翻译成 SQLite 查询语句。

数据库表结构与数据分布：
{schema_detail}

编写要求：
1. 只输出一条 SQL，不要任何解释、注释或前后缀文字。
2. 只能使用上面列出的表和字段名，严禁臆造表名或列名。
3. 日期字段格式为 'YYYY-MM-DD HH:MM:SS'，做日期筛选请用 strftime('%Y', InvoiceDate) = '2012' 这类写法。
4. 需要排名（最高/前 N/最多）时，用 ORDER BY ... LIMIT 或窗口函数 RANK()。
5. 必须带 LIMIT；不需要排序的查询也请加上 LIMIT 200。
6. 注意 JOIN 造成的重复累加：统计金额或数量时，若明细表有多行对应同一条记录，
   要么先聚合子查询，要么用 COUNT(DISTINCT 主键)。
7. 给每条 SQL 加一行注释说明它在算什么，格式为 -- 注释内容。

示例（供参考，不要照抄）：
需求：每个国家消费总额最高的 3 位客户
SQL：-- 按国家分组统计客户消费总额，取每组前三名
SELECT Country, FirstName, LastName, SUM(i.Total) AS 消费总额
FROM customers c JOIN invoices i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId
ORDER BY c.Country, 消费总额 DESC
LIMIT 200"""

GENERATE_USER = """用户需求：
{question}
{history}
请输出对应的 SQL。"""


class SQLGenerator:
    """基于大模型的 SQL 生成。"""

    def __init__(self, llm: LLMClient, parser: DBParser) -> None:
        self.llm = llm
        self.parser = parser
        self._detail_cache: dict[tuple, str] = {}

    def detail_for(self, tables: list[str]) -> str:
        key = tuple(sorted(tables))
        if key not in self._detail_cache:
            self._detail_cache[key] = self.parser.detail_for(list(tables))
        return self._detail_cache[key]

    @staticmethod
    def _history_block(history: list[dict]) -> str:
        if not history:
            return ""
        last = history[-1]
        return (
            f"\n对话历史：用户上一轮问「{last['question']}」，上一轮写的 SQL 是：\n"
            f"{last['sql']}\n\n"
            f"如果当前问题是追问，请在上一轮 SQL 的基础上修改（沿用相同的表和 JOIN，"
            f"调整筛选条件或分组维度），不要从头另起炉灶。"
        )

    def generate(self, question: str, tables: list[str], history: list[dict] | None = None) -> str:
        """生成 SQL，返回清洗后的纯 SQL 字符串。"""
        system = GENERATE_SYSTEM.format(schema_detail=self.detail_for(tables))
        user = GENERATE_USER.format(
            question=question, history=self._history_block(history or [])
        )
        raw = self.llm.chat(system, user)
        return clean_sql(raw)


def clean_sql(raw: str) -> str:
    """把大模型的原始输出清洗成纯 SQL。

    模型即使被要求"只输出 SQL"，也常会裹上 ```sql 围栏或加一句前缀，
    这里统一剥掉，避免把围栏当成 SQL 内容送进校验器。
    """
    sql = raw.strip()

    # 剥 ```sql ... ``` 围栏
    fenced = re.search(r"```(?:sql)?\s*(.+?)```", sql, re.DOTALL | re.IGNORECASE)
    if fenced:
        sql = fenced.group(1)

    # 去掉 "SQL:" / "查询语句：" 这类前缀行
    sql = re.sub(r"^(?:SQL|sql|查询语句|查询)\s*[:：]\s*", "", sql.strip())

    return sql.strip().rstrip(";").strip()