"""LLM 调用封装。

统一处理：超时、失败重试（指数退避）、调用日志、JSON 解析。
workflow 中所有需要大模型推理的步骤都通过这个类调用，不直接碰 openai 客户端。
"""

import json
import re
import time
from typing import Any

from openai import OpenAI

from . import config


class LLMError(RuntimeError):
    """LLM 调用或解析失败，且重试耗尽。"""


class LLMClient:
    """DashScope OpenAI 兼容模式客户端。"""

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        temperature: float | None = None,
    ) -> None:
        if not (api_key or config.DASHSCOPE_API_KEY):
            raise LLMError(
                "未找到 DASHSCOPE_API_KEY。\n"
                "请复制 .env.example 为 .env 并填入你的 DashScope API Key：\n"
                "    DASHSCOPE_API_KEY=sk-xxxxxxxxxxxxxxxx"
            )
        self.model = model or config.LLM_MODEL
        self.temperature = config.LLM_TEMPERATURE if temperature is None else temperature
        self.client = OpenAI(
            api_key=api_key or config.DASHSCOPE_API_KEY,
            base_url=config.DASHSCOPE_BASE_URL,
            timeout=config.LLM_TIMEOUT,
        )
        self.calls: list[dict[str, Any]] = []  # 调用日志，便于 notebook 展示

    # ------------------------------------------------------------------
    def chat(self, system: str, user: str, temperature: float | None = None) -> str:
        """调用大模型，返回文本内容。失败按指数退避重试。"""
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        last_err: Exception | None = None

        for attempt in range(config.LLM_MAX_RETRY):
            try:
                resp = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=self.temperature if temperature is None else temperature,
                )
                content = resp.choices[0].message.content or ""
                self.calls.append(
                    {
                        "model": self.model,
                        "prompt_chars": len(user),
                        "output_chars": len(content),
                        "attempt": attempt + 1,
                    }
                )
                return content
            except Exception as e:  # 网络抖动/限流/超时
                last_err = e
                if attempt < config.LLM_MAX_RETRY - 1:
                    time.sleep(2**attempt)

        raise LLMError(f"调用 {self.model} 失败，已重试 {config.LLM_MAX_RETRY} 次：{last_err}")

    # ------------------------------------------------------------------
    def chat_json(self, system: str, user: str, temperature: float | None = None) -> dict:
        """调用大模型并要求返回 JSON。

        大模型即使被要求输出 JSON 也可能裹 ```json 围栏或加解释文字，
        这里做三层兜底：直接解析 -> 剥围栏 -> 提取最外层花括号。
        """
        raw = self.chat(system, user, temperature=temperature)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            pass

        cleaned = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass

        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start != -1 and end > start:
            try:
                return json.loads(cleaned[start : end + 1])
            except json.JSONDecodeError:
                pass

        raise LLMError(f"大模型未返回可解析的 JSON：{raw[:300]}")