"""⑤ SQL 改写。

校验失败或执行报错时，把「原 SQL + 错误原因 + 表结构」一起回灌给大模型，
让它修好再试。这是 Agent 自我纠错的关键环节——没有它，一次生成失败就等于整个请求失败。
"""

from .db_parser import DBParser
from .llm import LLMClient

REWRITE_SYSTEM = """你是一个 SQL 修复专家。下面这条 SQL 校验或执行失败了，请根据错误原因修复它。

【可用表结构】
{schema_detail}

【出错的 SQL】
```sql
{sql}
```

【错误原因】
{errors}

修复要求：
1. 只输出修复后的完整 SQL，不要任何解释文字，不要用 ``` 包裹。
2. 优先修改导致报错的部分（比如列名写错、表名写错、JOIN 条件写错、函数不存在），
   其余部分尽量保持原样。
3. 仍然只能使用上面列出的表和字段。
4. 必须带 LIMIT。"""

REWRITE_USER = """【用户需求】
{question}

请输出修复后的 SQL。"""


class SQLRewriter:
    """基于大模型的 SQL 纠错。"""

    def __init__(self, llm: LLMClient, parser: DBParser) -> None:
        self.llm = llm
        self.parser = parser

    def rewrite(
        self,
        question: str,
        sql: str,
        errors: list[str],
        tables: list[str] | None = None,
    ) -> str:
        """根据错误原因改写 SQL。

        tables 为空时从原 SQL 里猜（用 DBParser 已知表名做交集），猜不到就给全库结构。
        """
        if not tables:
            guessed = [t for t in self.parser.table_names if t in sql]
            tables = guessed or list(self.parser.table_names)

        system = REWRITE_SYSTEM.format(
            schema_detail=self.parser.detail_for(tables),
            sql=sql,
            errors="\n".join(f"- {e}" for e in errors),
        )
        user = REWRITE_USER.format(question=question)

        # 修复需要一点自由度，temperature 调高一点避免每次都重复原错误
        raw = self.llm.chat(system, user, temperature=0.3)

        from .sql_generator import clean_sql  # 局部导入避免循环依赖

        return clean_sql(raw)