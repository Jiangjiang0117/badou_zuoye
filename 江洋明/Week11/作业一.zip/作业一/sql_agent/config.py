"""SQL Agent 全局配置。

密钥只从环境变量或同目录 .env 文件读取，代码中不出现真实 key
（参考 CLAUDE.md：新代码不要硬编码密钥）。
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    """极简 .env 加载：解析 KEY=VALUE 行，# 开头为注释。不覆盖已有环境变量。"""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(BASE_DIR / ".env")

# ---------------- LLM ----------------
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY", "")
DASHSCOPE_BASE_URL = os.getenv(
    "DASHSCOPE_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"
)
LLM_MODEL = os.getenv("LLM_MODEL", "qwen-plus")
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.0"))
LLM_TIMEOUT = int(os.getenv("LLM_TIMEOUT", "60"))
LLM_MAX_RETRY = int(os.getenv("LLM_MAX_RETRY", "3"))

# ---------------- 数据库 ----------------
DB_FILE = BASE_DIR / "chinook.db"
DB_URL = f"sqlite:///{DB_FILE.as_posix()}"
# 只读 URI：mode=ro 让 SQLite 在数据库层拒绝一切写操作，比 Python 侧的检查更可靠
DB_URL_READONLY = f"sqlite:///file:{DB_FILE.as_posix()}?mode=ro&uri=true"

# ---------------- 运行参数 ----------------
MAX_REWRITE = int(os.getenv("MAX_REWRITE", "3"))  # SQL 改写最大轮数
DEFAULT_LIMIT = int(os.getenv("DEFAULT_LIMIT", "200"))  # 无 LIMIT 时自动补上的行数
MAX_ROWS = int(os.getenv("MAX_ROWS", "200"))  # 结果返回行数上限
SQL_TIMEOUT = int(os.getenv("SQL_TIMEOUT", "10"))  # SQL 执行超时（秒）