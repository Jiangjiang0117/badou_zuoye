"""② table 选择。

把「自然语言问题 + 全库 schema 摘要」交给大模型，让它挑出需要用到的表。
只输出表名，具体怎么 JOIN 交给生成 SQL 那一步根据外键关系自己推导。
"""

from .db_parser import DBParser
from .llm import LLMClient

SELECT_SYSTEM = """你是一个数据分析场景下的选表专家。用户会提出一个自然语言的取数需求，
你的任务是从给定的数据库表清单中选出完成这个需求需要用到的表。

要求：
1. 只输出 JSON，不要输出任何其他文字。格式：
   {"tables": ["表名1", "表名2"], "reason": "一句话说明为什么选这些表"}
2. tables 中的表名必须原样取自下面的【数据库表清单】，严禁臆造表名。
3. 需求需要关联多张表时，把所有要 JOIN 的表都列出来。
4. 拿不准时宁可多选也不要漏选，多余的表不会造成危害，漏表会导致 SQL 无法执行。
5. 如果需求与数据库完全无关，tables 返回空数组。"""

SELECT_USER = """【数据库表清单】
{schema}

【用户需求】
{question}
{history}"""


class TableSelector:
    """基于大模型的选表。"""

    def __init__(self, llm: LLMClient, parser: DBParser) -> None:
        self.llm = llm
        self.parser = parser
        self._summary_cache: str | None = None  # 全库摘要算一次就够

    def schema_summary(self) -> str:
        if self._summary_cache is None:
            self._summary_cache = self.parser.schema_summary()
        return self._summary_cache

    @staticmethod
    def _history_block(history: list[dict]) -> str:
        if not history:
            return ""
        last = history[-1]
        return (
            f"\n\n【对话历史】用户上一轮问的是「{last['question']}」，"
            f"当时用的表是 {last['tables']}。\n"
            f"如果当前问题是在追问上一轮（例如「再看看…」「只按…拆分」），"
            f"请沿用上一轮的表。"
        )

    def select(self, question: str, history: list[dict] | None = None) -> tuple[list[str], str]:
        """返回 (选中的表, 选表理由)。

        大模型可能返回不存在的表名，这种情况下记警告并回退到全部表，
        保证流程不中断——后续的 SQL 校验还能再兜一层。
        """
        user = SELECT_USER.format(
            schema=self.schema_summary(),
            question=question,
            history=self._history_block(history or []),
        )
        data = self.llm.chat_json(SELECT_SYSTEM, user)

        tables = data.get("tables") or []
        reason = data.get("reason", "")

        if isinstance(tables, str):  # 模型偶尔会把单个表名写成字符串
            tables = [tables]
        valid = [t for t in tables if t in self.parser.table_names]
        unknown = [t for t in tables if t not in self.parser.table_names]

        if unknown:
            reason += f"（注意：模型给出了不存在的表 {unknown}，已忽略）"
        if not valid:
            # 选表失败不该让整个 workflow 挂掉，退回全表让生成阶段自己挑
            valid = list(self.parser.table_names)
            reason += "（选表结果无效，回退为全部表）"

        return valid, reason