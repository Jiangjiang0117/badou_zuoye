"""① 数据库解析。

参考 sql-agent.ipynb 的 DBParser，修复了 3 个在 SQLAlchemy 2.0 下会直接报错的地方：
  1. ``engine.execute(sql)``      —— 2.0 已删除，必须 ``conn.execute(text(sql))``
  2. ``filter(col == None)``     —— 2.0 拒绝与 None 比较，必须用 ``col.is_(None)``
  3. 连接未设只读               —— 改用 mode=ro 的 SQLite URI，数据库层拒绝写入

新增：中文业务注释映射 + schema_summary()，把解析结果压成给大模型看的紧凑 DDL。
"""

from typing import Any

import pandas as pd
from sqlalchemy import MetaData, Table, create_engine, func, inspect, select, text

from . import config

# 数据库是音乐商店销售数据（Chinook），给每张表/每个字段配中文注释，
# 大模型看到中文注释比只看英文列名选表准得多。
TABLE_CN: dict[str, str] = {
    "albums": "专辑表",
    "artists": "艺术家/歌手表",
    "customers": "客户表",
    "employees": "员工表：销售代表，customers.SupportRepId 指向本表",
    "genres": "音乐流派表",
    "invoice_items": "订单明细表（一条订单里买了哪些曲目）",
    "invoices": "订单表：客户的购买记录，含下单日期和订单总金额",
    "media_types": "媒体类型表",
    "playlist_track": "播放列表与曲目的关联表",
    "playlists": "播放列表表",
    "tracks": "曲目/歌曲表（专辑内的一首首歌）",
}

COLUMN_CN: dict[str, dict[str, str]] = {
    "albums": {"AlbumId": "专辑ID", "Title": "专辑名称", "ArtistId": "所属艺术家ID"},
    "artists": {"ArtistId": "艺术家ID", "Name": "艺术家姓名"},
    "customers": {
        "CustomerId": "客户ID", "FirstName": "名", "LastName": "姓", "Company": "公司",
        "Address": "地址", "City": "城市", "State": "州/省", "Country": "国家",
        "PostalCode": "邮编", "Phone": "电话", "Fax": "传真", "Email": "邮箱",
        "SupportRepId": "服务该客户的销售员工ID",
    },
    "employees": {
        "EmployeeId": "员工ID", "LastName": "姓", "FirstName": "名", "Title": "职位",
        "ReportsTo": "直属上级员工ID", "BirthDate": "出生日期", "HireDate": "入职日期",
        "Address": "地址", "City": "城市", "State": "州/省", "Country": "国家",
        "PostalCode": "邮编", "Phone": "电话", "Fax": "传真", "Email": "邮箱",
    },
    "genres": {"GenreId": "流派ID", "Name": "流派名称"},
    "invoice_items": {
        "InvoiceLineId": "明细ID", "InvoiceId": "所属订单ID", "TrackId": "曲目ID",
        "UnitPrice": "单价", "Quantity": "数量",
    },
    "invoices": {
        "InvoiceId": "订单ID", "CustomerId": "下单客户ID", "InvoiceDate": "下单日期",
        "BillingAddress": "账单地址", "BillingCity": "账单城市", "BillingState": "账单州/省",
        "BillingCountry": "账单国家", "BillingPostalCode": "账单邮编",
        "Total": "订单总金额",
    },
    "media_types": {"MediaTypeId": "媒体类型ID", "Name": "媒体类型名称"},
    "playlist_track": {"PlaylistId": "播放列表ID", "TrackId": "曲目ID"},
    "playlists": {"PlaylistId": "播放列表ID", "Name": "播放列表名称"},
    "tracks": {
        "TrackId": "曲目ID", "Name": "曲目名称", "AlbumId": "所属专辑ID",
        "MediaTypeId": "媒体类型ID", "GenreId": "流派ID", "Composer": "作曲者",
        "Milliseconds": "时长(毫秒)", "Bytes": "文件大小(字节)", "UnitPrice": "单价",
    },
}


class DBParser:
    """解析数据库结构、字段统计、外键关系和样例数据。"""

    def __init__(self, db_url: str | None = None, read_only: bool = True) -> None:
        if db_url is None:
            db_url = config.DB_URL_READONLY if read_only else config.DB_URL
        # 即便调用方传了普通 sqlite URL，只要目标是本地文件也强制转只读
        elif read_only and db_url.startswith("sqlite:///") and "mode=ro" not in db_url:
            path = db_url[len("sqlite:///") :]
            db_url = f"sqlite:///file:{path}?mode=ro&uri=true"

        self.db_url = db_url
        self.engine = create_engine(db_url, echo=False)
        self.conn = self.engine.connect()
        self.inspector = inspect(self.engine)
        self.table_names: list[str] = self.inspector.get_table_names()

        self._table_fields: dict[str, dict[str, dict]] = {}
        self._table_sample: dict[str, pd.DataFrame] = {}
        self.foreign_keys: list[dict] = []
        self._row_counts: dict[str, int] = {}

        self._parse_all_tables()

    # ------------------------------------------------------------------
    def _parse_all_tables(self) -> None:
        """逐表统计字段信息、外键和样例数据。"""
        for table_name in self.table_names:
            columns = self.inspector.get_columns(table_name)
            self._table_fields[table_name] = {c["name"]: dict(c) for c in columns}

            self.foreign_keys += [
                {
                    "constrained_table": table_name,
                    "constrained_columns": fk["constrained_columns"],
                    "referred_table": fk["referred_table"],
                    "referred_columns": fk["referred_columns"],
                }
                for fk in self.inspector.get_foreign_keys(table_name)
            ]

            table_instance = Table(table_name, MetaData(), autoload_with=self.engine)
            self._row_counts[table_name] = (
                self.conn.execute(select(func.count()).select_from(table_instance)).scalar() or 0
            )
            # 注意要逐字段合并：直接 update 会把字段原有的 type 等元信息整个覆盖掉
            for col_name, stats in self._profile_columns(table_instance, columns).items():
                self._table_fields[table_name][col_name].update(stats)
            self._table_sample[table_name] = self._fetch_sample(table_instance)

    def _profile_columns(
        self, table_instance: Table, columns: list[dict]
    ) -> dict[str, dict]:
        """对每个字段做统计：去重数、空值数、最大最小值、众数、样例值。"""
        stats: dict[str, dict] = {}

        for column_meta in columns:
            name = column_meta["name"]
            column = table_instance.columns[name]
            field: dict[str, Any] = {}

            # 去重值个数
            field["distinct"] = self.conn.execute(
                select(func.count(func.distinct(column)))
            ).scalar()

            # 空值个数（SQLAlchemy 2.0 不允许 col == None）
            field["nan_count"] = self.conn.execute(
                select(func.count()).select_from(table_instance).where(column.is_(None))
            ).scalar()

            field["max"] = self.conn.execute(select(func.max(column))).scalar()
            field["min"] = self.conn.execute(select(func.min(column))).scalar()

            type_str = str(column_meta["type"]).lower()

            # 文本类字段补众数，大模型靠它理解枚举值的真实写法（如 Country='USA'）
            if "char" in type_str or "text" in type_str:
                top = self.conn.execute(
                    select(column, func.count().label("cnt"))
                    .group_by(column)
                    .order_by(func.count().desc())
                    .limit(1)
                ).first()
                field["mode"] = top[0] if top else None

            # 抽样几个真实取值
            sample = self.conn.execute(select(column).limit(10)).scalars().all()
            uniq = list({str(v) for v in sample if v is not None})
            field["random"] = uniq[:3]

            stats[name] = field

        return stats

    def _fetch_sample(self, table_instance: Table) -> pd.DataFrame:
        row = self.conn.execute(select(table_instance)).first()
        columns = [c.name for c in table_instance.columns]
        return pd.DataFrame([tuple(row)] if row else [], columns=columns)

    # ------------------------------------------------------------------
    # 对外接口
    # ------------------------------------------------------------------
    def get_table_fields(self, table_name: str) -> pd.DataFrame:
        """字段统计信息（distinct / nan_count / min / max / mode / random）。"""
        return pd.DataFrame.from_dict(self._table_fields[table_name]).T

    def get_data_relations(self) -> pd.DataFrame:
        """外键关系表。"""
        return pd.DataFrame(self.foreign_keys)

    def get_table_sample(self, table_name: str) -> pd.DataFrame:
        """表的第一行样例。"""
        return self._table_sample[table_name]

    def get_row_count(self, table_name: str) -> int:
        return self._row_counts.get(table_name, 0)

    def join_path(self, tables: list[str]) -> list[str]:
        """返回给定表集合内部实际存在的 JOIN 关系描述，供生成 SQL 时参考。"""
        table_set = set(tables)
        return [
            f"{fk['constrained_table']}.{fk['constrained_columns']} = "
            f"{fk['referred_table']}.{fk['referred_columns']}"
            for fk in self.foreign_keys
            if fk["constrained_table"] in table_set
            and fk["referred_table"] in table_set
            and fk["constrained_table"] != fk["referred_table"]
        ]

    # ------------------------------------------------------------------
    def schema_summary(self, tables: list[str] | None = None) -> str:
        """生成给大模型选表用的全库摘要（带中文注释的紧凑 DDL）。

        tables 为 None 时输出全部表。字段统计不进摘要，避免 token 爆炸，
        那部分由 generate_sql 阶段按需提供。
        """
        targets = tables if tables is not None else self.table_names
        lines: list[str] = []

        for name in targets:
            if name not in self._table_fields:
                continue
            cn = TABLE_CN.get(name, "")
            lines.append(f"### {name}（{cn}）  共 {self.get_row_count(name)} 行")
            for col_name, meta in self._table_fields[name].items():
                col_cn = COLUMN_CN.get(name, {}).get(col_name, "")
                note = f"  -- {col_cn}" if col_cn else ""
                lines.append(f"  {col_name} {meta['type']}{note}")
            lines.append("")

        # 外键单独列一段：告诉模型表之间怎么 JOIN
        relevant = [
            fk
            for fk in self.foreign_keys
            if fk["constrained_table"] in set(targets) or fk["referred_table"] in set(targets)
        ]
        if relevant:
            lines.append("### 表间关联（JOIN 用）")
            for fk in relevant:
                lines.append(
                    f"  {fk['constrained_table']}.{fk['constrained_columns']}"
                    f" -> {fk['referred_table']}.{fk['referred_columns']}"
                )

        return "\n".join(lines)

    def detail_for(self, tables: list[str]) -> str:
        """生成 SQL 阶段用的详细上下文：字段统计 + 样例行 + JOIN 关系。"""
        parts: list[str] = []

        for name in tables:
            if name not in self._table_fields:
                continue
            cn = TABLE_CN.get(name, "")
            fields = self.get_table_fields(name)

            # 字段统计压成紧凑文本：只保留对写 SQL 有用的部分
            stat_lines = []
            for col_name, row in fields.iterrows():
                col_cn = COLUMN_CN.get(name, {}).get(col_name, "")
                bits = [f"类型={row['type']}"]
                if row.get("nan_count"):
                    bits.append(f"空值数={int(row['nan_count'])}")
                if col_name.lower().endswith("id"):
                    bits.append(f"取值范围={row['min']}~{row['max']}")
                elif isinstance(row.get("mode"), str):
                    bits.append(f"出现最多的值='{row['mode']}'")
                if isinstance(row.get("random"), list) and row["random"]:
                    bits.append(f"样例值={row['random']}")
                stat_lines.append(
                    f"    {col_name}（{col_cn}）: " + ", ".join(bits)
                )

            header = f"### 表 {name}（{cn}）" if cn else f"### 表 {name}"
            sample = self.get_table_sample(name)
            if len(sample):
                first = ", ".join(f"{k}={v!r}" for k, v in sample.iloc[0].items())
                stat_lines.append(f"    首行样例: {first}")
            else:
                stat_lines.append("    （空表）")

            parts.append(header + "\n" + "\n".join(stat_lines))

        joins = self.join_path(tables)
        if joins:
            parts.append("### 可用 JOIN 条件\n" + "\n".join(f"  {j}" for j in joins))

        return "\n\n".join(parts)

    # ------------------------------------------------------------------
    def execute_sql(self, sql: str) -> pd.DataFrame:
        """执行只读 SQL，返回 DataFrame。"""
        result = self.conn.execute(text(sql))
        return pd.DataFrame(result.fetchall(), columns=list(result.keys()))

    def close(self) -> None:
        self.conn.close()
        self.engine.dispose()

    def __enter__(self) -> "DBParser":
        return self

    def __exit__(self, *exc) -> None:
        self.close()