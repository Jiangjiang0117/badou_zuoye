"""SQL Agent workflow 编排。

把七个步骤串成一条流水线，并维护多轮对话上下文：

    ①解析 -> ②选表 -> ③生成 -> ④校验 -> ⑥执行 -> ⑦汇总
                              ^       |
                              └─⑤改写─┘   校验或执行失败都回到改写

其中 ④⑤⑥ 是一个循环：校验通过不代表能执行成功（语法合法但列名不存在等），
所以两条失败路径要汇到同一个改写环节。
"""

import time
from dataclasses import dataclass, field
from typing import Callable

import pandas as pd

from . import config
from .db_parser import DBParser
from .llm import LLMClient
from .sql_executor import ExecResult, SQLExecutor
from .sql_generator import SQLGenerator
from .sql_rewriter import SQLRewriter
from .sql_validator import validate_sql
from .summarizer import Summarizer
from .table_selector import TableSelector


class WorkflowError(RuntimeError):
    """Workflow 失败（改写次数耗尽仍无法得到可执行的 SQL）。"""

    def __init__(self, message: str, trace: list["StepTrace"] | None = None) -> None:
        super().__init__(message)
        self.trace = trace or []


@dataclass
class StepTrace:
    """单步执行记录，用于 notebook / CLI 展示 Agent 的思考过程。"""

    name: str
    ok: bool = True
    detail: str = ""
    elapsed_ms: float = 0.0
    error: str = ""


@dataclass
class AgentAnswer:
    """一次问答的完整结果。"""

    question: str
    tables: list[str]
    sql: str
    df: pd.DataFrame
    summary: str
    rewrites: int
    elapsed_ms: float
    row_count: int
    trace: list[StepTrace] = field(default_factory=list)


class SQLAgent:
    """自然语言取数 Agent。"""

    def __init__(
        self,
        db_url: str | None = None,
        llm: LLMClient | None = None,
        max_rewrite: int | None = None,
    ) -> None:
        self.llm = llm or LLMClient()
        self.parser = DBParser(db_url or config.DB_URL_READONLY)
        self.executor = SQLExecutor()

        self.selector = TableSelector(self.llm, self.parser)
        self.generator = SQLGenerator(self.llm, self.parser)
        self.rewriter = SQLRewriter(self.llm, self.parser)
        self.summarizer = Summarizer(self.llm)

        self.max_rewrite = config.MAX_REWRITE if max_rewrite is None else max_rewrite
        self.history: list[dict] = []  # 多轮上下文

    # ------------------------------------------------------------------
    def reset(self) -> None:
        """清空多轮对话上下文。"""
        self.history.clear()

    def run(self, question: str, on_step: Callable[[StepTrace], None] | None = None) -> AgentAnswer:
        """执行完整 workflow，返回答案。

        on_step 是每完成一步的回调，notebook 用它做逐步展示。
        """
        trace: list[StepTrace] = []
        start = time.time()

        def emit(step: StepTrace) -> None:
            trace.append(step)
            if on_step:
                on_step(step)

        def timed(name: str, ok: bool, detail: str, t0: float, error: str = "") -> StepTrace:
            return StepTrace(
                name=name, ok=ok, detail=detail,
                elapsed_ms=(time.time() - t0) * 1000, error=error,
            )

        # ---------- ① 数据库解析（只解析一次，后续复用） ----------
        t0 = time.time()
        detail = (
            f"{len(self.parser.table_names)} 张表: {', '.join(self.parser.table_names)}\n"
            f"共 {len(self.parser.foreign_keys)} 条外键关系"
        )
        emit(timed("① 数据库解析", True, detail, t0))

        # ---------- ② table 选择 ----------
        t0 = time.time()
        try:
            tables, reason = self.selector.select(question, self.history)
            emit(timed("② table 选择", True, f"选中 {tables}\n理由: {reason}", t0))
        except Exception as e:
            step = timed("② table 选择", False, "", t0, f"{type(e).__name__}: {e}")
            emit(step)
            raise WorkflowError(f"选表失败：{e}", trace) from e

        # ---------- ③ SQL 生成 ----------
        t0 = time.time()
        try:
            sql = self.generator.generate(question, tables, self.history)
            emit(timed("③ SQL 生成", True, sql, t0))
        except Exception as e:
            step = timed("③ SQL 生成", False, "", t0, f"{type(e).__name__}: {e}")
            emit(step)
            raise WorkflowError(f"SQL 生成失败：{e}", trace) from e

        # ---------- ④⑤⑥ 校验 / 执行 / 改写 循环 ----------
        rewrites = 0
        exec_result: ExecResult | None = None

        for attempt in range(self.max_rewrite + 1):
            is_last = attempt == self.max_rewrite
            round_suffix = "" if rewrites == 0 else f"（第{rewrites + 1}轮）"
            errors: list[str] = []

            # ④ 校验
            t0 = time.time()
            validation = validate_sql(sql, self.parser)
            if not validation.ok:
                errors = validation.errors
                emit(
                    timed(
                        f"④ SQL 校验{round_suffix}", False, "", t0, "；".join(errors)
                    )
                )
            else:
                sql = validation.sql  # 规范化后的 SQL（可能补了 LIMIT）
                emit(
                    timed(
                        f"④ SQL 校验{round_suffix}",
                        True,
                        "\n".join(validation.warnings) or "全部规则通过",
                        t0,
                    )
                )

                # ⑥ 执行
                t0 = time.time()
                try:
                    exec_result = self.executor.execute(sql)
                    emit(
                        timed(
                            f"⑥ SQL 执行{round_suffix}",
                            True,
                            f"{exec_result.row_count} 行，耗时 {exec_result.elapsed_ms:.1f}ms"
                            + ("（已截断）" if exec_result.truncated else ""),
                            t0,
                        )
                    )
                    break
                except Exception as e:
                    errors = [f"{type(e).__name__}: {e}"]
                    emit(
                        timed(
                            f"⑥ SQL 执行{round_suffix}", False, "", t0, "；".join(errors)
                        )
                    )

            # 失败 -> ⑤ 改写（最后一轮失败则直接放弃）
            if is_last:
                raise WorkflowError(
                    f"经过 {self.max_rewrite} 轮改写仍无法得到可执行的 SQL：\n"
                    + "\n".join(f"- {e}" for e in errors),
                    trace,
                )

            t0 = time.time()
            try:
                new_sql = self.rewriter.rewrite(question, sql, errors, tables)
            except Exception as e:
                emit(timed("⑤ SQL 改写", False, "", t0, f"{type(e).__name__}: {e}"))
                raise WorkflowError(f"SQL 改写失败：{e}", trace) from e

            rewrites += 1
            emit(
                timed(
                    f"⑤ SQL 改写（第{rewrites}轮）",
                    True,
                    f"原错误: {errors[0][:120]}\n改写为: {new_sql}",
                    t0,
                )
            )
            sql = new_sql

        assert exec_result is not None  # 循环正常退出时必然已执行成功

        # ---------- ⑦ 结果汇总 ----------
        t0 = time.time()
        try:
            summary = self.summarizer.summarize(question, sql, exec_result)
            emit(timed("⑦ 结果汇总", True, summary, t0))
        except Exception as e:
            # 汇总失败不该让已经查到的数据作废，降级成程序化描述
            summary = (
                f"查询成功，共返回 {exec_result.row_count} 行"
                f"（自动生成回答失败：{e}）"
            )
            emit(timed("⑦ 结果汇总", False, summary, t0, f"{type(e).__name__}: {e}"))

        self.history.append({"question": question, "sql": sql, "tables": tables})

        return AgentAnswer(
            question=question,
            tables=tables,
            sql=sql,
            df=exec_result.df,
            summary=summary,
            rewrites=rewrites,
            elapsed_ms=(time.time() - start) * 1000,
            row_count=exec_result.row_count,
            trace=trace,
        )

    # ------------------------------------------------------------------
    def close(self) -> None:
        self.executor.close()
        self.parser.close()

    def __enter__(self) -> "SQLAgent":
        return self

    def __exit__(self, *exc) -> None:
        self.close()