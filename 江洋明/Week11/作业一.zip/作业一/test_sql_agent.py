"""SQL Agent workflow 测试。

用 MockLLM 顶替真实大模型，因此不需要 API Key 就能验证编排逻辑：
重试循环、多轮上下文、危险 SQL 拦截、失败兜底。

运行：
    python test_sql_agent.py
"""

import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

from sql_agent.agent import SQLAgent, WorkflowError
from sql_agent.sql_generator import clean_sql

# ---------------------------------------------------------------------------
# Mock LLM：按 system prompt 里的特征词分发到不同的返回值
# ---------------------------------------------------------------------------


class MockLLM:
    """模拟大模型。

    - generation: 正常情况下生成的 SQL
    - bad_generations: 前 N 次「生成」返回 bad_sql，之后恢复正常
      （改写始终返回正常的 generation，用来模拟"改一次就好了"）
    - always_bad: 生成和改写都返回 bad_sql，用来模拟怎么改都改不对
    """

    def __init__(self, generation: str, bad_generations: int = 0, bad_sql: str | None = None,
                 tables: list[str] | None = None, always_bad: bool = False) -> None:
        self.generation = generation
        self.bad_generations = bad_generations
        self.bad_sql = bad_sql or "SELECT NoSuchColumn FROM customers"
        self.tables = tables or ["customers"]
        self.always_bad = always_bad
        self.calls: list[str] = []
        self.prompts_seen: list[dict] = []

    def chat(self, system: str, user: str, temperature: float | None = None) -> str:
        self.calls.append(system[:20])
        self.prompts_seen.append({"system": system, "user": user})

        if "选表专家" in system:
            return self.chat_json(system, user)
        if "SQL 修复专家" in system:
            bad = self.always_bad
            # 带 ```sql 围栏，顺便验证 clean_sql 能处理脏输出
            return f"```sql\n{self.bad_sql if bad else self.generation}\n```"
        if "数据分析助手" in system:
            return "mock 生成的汇总回答。"

        if self.always_bad or self.bad_generations > 0:
            self.bad_generations -= 1
            return self.bad_sql
        return self.generation

    def chat_json(self, system: str, user: str, temperature: float | None = None) -> dict:
        return {"tables": self.tables, "reason": "mock 选表"}


# ---------------------------------------------------------------------------
# 测试用例
# ---------------------------------------------------------------------------

GOOD_SQL = (
    "SELECT c.Country, SUM(i.Total) AS 总额 FROM customers c "
    "JOIN invoices i ON c.CustomerId = i.CustomerId "
    "GROUP BY c.Country ORDER BY 总额 DESC LIMIT 5"
)

PASSED: list[str] = []
FAILED: list[str] = []


def check(name: str, condition: bool, extra: str = "") -> None:
    if condition:
        PASSED.append(name)
        print(f"  PASS  {name}")
    else:
        FAILED.append(name)
        print(f"  FAIL  {name}" + (f"  -> {extra}" if extra else ""))


def test_happy_path() -> None:
    """正常流程：一次生成就通过校验并执行。"""
    print("\n[用例1] 正常流程")
    agent = SQLAgent(llm=MockLLM(GOOD_SQL))
    try:
        ans = agent.run("各国消费总额")
        check("无改写", ans.rewrites == 0, f"实际改写 {ans.rewrites} 轮")
        check("选中正确的表", ans.tables == ["customers"], str(ans.tables))
        check("返回 5 行", ans.row_count == 5, f"实际 {ans.row_count}")
        # 正常流程不该出现"⑤ SQL 改写"——没有错误就不需要改写，所以是 6 步不是 7 步
        check("trace 记录 6 步（无错误则跳过改写）", len(ans.trace) == 6, f"实际 {len(ans.trace)} 步")
        check(
            "trace 步骤名正确",
            [s.name for s in ans.trace][:2] == ["① 数据库解析", "② table 选择"],
            str([s.name for s in ans.trace]),
        )
        check("SQL 被自动补 LIMIT", "LIMIT" in ans.sql.upper())
    finally:
        agent.close()


def test_rewrite_loop() -> None:
    """生成错误 SQL -> 校验失败 -> 改写 -> 成功。"""
    print("\n[用例2] SQL 改写循环")
    agent = SQLAgent(llm=MockLLM(GOOD_SQL, bad_generations=1))
    try:
        ans = agent.run("各国消费总额")
        check("触发了一次改写", ans.rewrites == 1, f"实际 {ans.rewrites} 轮")
        check("改写后执行成功", ans.row_count == 5)
        names = [s.name for s in ans.trace]
        check(
            "校验失败被记入 trace",
            any("校验" in n and not s.ok for n, s in zip(names, ans.trace)),
        )
        check(
            "改写步骤被记入 trace",
            any("改写" in n for n in names),
            str(names),
        )
    finally:
        agent.close()


def test_dangerous_sql_blocked() -> None:
    """模型生成 DELETE 时必须被拦截并改写，不能真的执行。"""
    print("\n[用例3] 危险 SQL 拦截")
    agent = SQLAgent(llm=MockLLM(GOOD_SQL, bad_generations=1, bad_sql="DELETE FROM invoices"))
    try:
        ans = agent.run("删掉所有订单")
        check("危险 SQL 被拦截后改写成功", ans.rewrites == 1 and ans.row_count == 5)
        errors = " ".join(s.error for s in ans.trace if s.error)
        check("拦截原因被记录", "SELECT" in errors or "禁止" in errors, errors[:80])
    finally:
        agent.close()


def test_rewrite_exhausted() -> None:
    """改写次数耗尽应抛 WorkflowError，而不是死循环或静默失败。"""
    print("\n[用例4] 改写次数耗尽")
    agent = SQLAgent(llm=MockLLM(GOOD_SQL, always_bad=True), max_rewrite=2)
    try:
        agent.run("随便问个问题")
        check("应抛出 WorkflowError", False, "没有抛异常")
    except WorkflowError as e:
        check("应抛出 WorkflowError", True)
        check("错误信息包含最终原因", "no such column" in str(e).lower() or "预演失败" in str(e))
    finally:
        agent.close()


def test_multi_turn() -> None:
    """多轮追问：第二轮的 prompt 里应带上第一轮的 SQL。"""
    print("\n[用例5] 多轮上下文")
    llm = MockLLM(GOOD_SQL)
    agent = SQLAgent(llm=llm)
    try:
        agent.run("各国消费总额")
        check("第一轮后 history 有 1 条", len(agent.history) == 1)

        llm.prompts_seen.clear()
        agent.run("只看美国")
        check("第二轮后 history 有 2 条", len(agent.history) == 2)

        gen_prompts = [p for p in llm.prompts_seen if "SQL 专家" in p["system"]]
        check("第二轮生成 prompt 存在", len(gen_prompts) >= 1)
        if gen_prompts:
            user = gen_prompts[-1]["user"]
            check("携带了上一轮 SQL", GOOD_SQL[:40] in user, user[:120])
            check("携带了上一轮问题", "各国消费总额" in user)

        agent.reset()
        check("reset 清空 history", len(agent.history) == 0)
    finally:
        agent.close()


def test_table_fallback() -> None:
    """模型返回不存在的表名时应回退到全部表而不是崩溃。"""
    print("\n[用例6] 选表兜底")

    class BadTableLLM(MockLLM):
        def chat_json(self, system, user, temperature=None):
            return {"tables": ["orders", "sales"], "reason": "mock 幻觉表名"}

    agent = SQLAgent(llm=BadTableLLM(GOOD_SQL))
    try:
        ans = agent.run("各国消费总额")
        check("幻觉表名被回退为全表", len(ans.tables) == 11, f"实际 {ans.tables}")
        check("流程未中断", ans.row_count == 5)
    finally:
        agent.close()


def test_clean_sql() -> None:
    """清洗大模型输出的脏格式。"""
    print("\n[用例7] SQL 输出清洗")
    cases = [
        ("```sql\nSELECT 1\n```", "SELECT 1"),
        ("SQL: SELECT 2", "SELECT 2"),
        ("查询语句：SELECT 3;", "SELECT 3"),
        ("SELECT 4", "SELECT 4"),
        ("```\nSELECT 5 FROM t\n```", "SELECT 5 FROM t"),
    ]
    for raw, expected in cases:
        got = clean_sql(raw)
        check(f"clean_sql({raw[:22]!r})", got == expected, f"得到 {got!r}")


# ---------------------------------------------------------------------------


def main() -> int:
    print("=" * 70)
    print("SQL Agent workflow 测试（Mock LLM，不需要 API Key）")
    print("=" * 70)

    for fn in [
        test_happy_path,
        test_rewrite_loop,
        test_dangerous_sql_blocked,
        test_rewrite_exhausted,
        test_multi_turn,
        test_table_fallback,
        test_clean_sql,
    ]:
        fn()

    print("\n" + "=" * 70)
    print(f"测试结果: {len(PASSED)} 通过, {len(FAILED)} 失败")
    if FAILED:
        for name in FAILED:
            print(f"  失败: {name}")
    print("=" * 70)
    return 0 if not FAILED else 1


if __name__ == "__main__":
    raise SystemExit(main())